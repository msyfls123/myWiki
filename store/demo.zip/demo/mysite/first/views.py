from django.shortcuts import render,render_to_response
from models import Beauty
# Create your views here.
def index(request):
	data = Beauty.objects.all()
	context = {}
	context["data"] = data
	return render(request,'index.html',context)

def page_not_found(request):
    return render_to_response('40X.html')

def page_error(request):
    return render_to_response('50X.html')