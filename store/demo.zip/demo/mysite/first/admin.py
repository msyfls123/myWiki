from django.contrib import admin

# Register your models here.
import models

class BeautyAdmin(admin.ModelAdmin):
	list_display = ["name","img"]
	search_fields = ('name',)
	list_filter = ('name',)
	
admin.site.register(models.Beauty,BeautyAdmin)